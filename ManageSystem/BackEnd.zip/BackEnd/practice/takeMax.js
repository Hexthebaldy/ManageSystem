var arr2 = [
    [4, 5, 1, 3],
    [1327, 18, 16, 26],
    [32, 35, 37, 39],
    [1000, 1001, 857, 1],
];
function takeBig(arr) {
    var brr = [];
    arr.forEach(function (item) {
        brr.push(Math.max.apply(Math, item));
    });
    return brr;
}
var arr = takeBig(arr2);
console.log('filterd: ', arr);
console.log('What?');
