let str = "world";

String.prototype.addPreFix = function(){
    return 'Hello '+ this;
}

console.log(str.addPreFix());