let str = "aaabbabsseeffeefgrrgr";
let stats = {

}


for(let i=0;i<str.length;i++){
    if(stats[str[i]]){
        stats[str[i]] += 1;
    }else{
        stats[str[i]] = 1;
    }
}

let max = 0;

for(let item in stats){
    if(max<stats[item]){
        max = stats[item];
    }
}

for(let key in stats){
    if(max == stats[key]){
        console.log(key);
        console.log(stats[key]);
    }
}

console.log(max);


console.log(stats);