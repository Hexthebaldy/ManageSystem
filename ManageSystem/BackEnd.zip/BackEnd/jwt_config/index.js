module.exports = {
	jwtSecretKey:'qd_xiaowang',
}